<?php
$link=mysqli_connect("localhost","root","","college");
if($link===false)
{
    die ("not connected sucessfully");
}

?>