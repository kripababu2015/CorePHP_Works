<html>
<head>
	<title>
		Registration Form
	</title>
	<style>
		table
		{
			text-align:center;
			margin: 20px;
			padding:20px;

		}
		body
		{
			text-align: center;
			margin:30px;
		}
		tr,td
		{
			margin:30px;
			padding: 15px;
		}
		fieldset
		{
			width:500px;

			margin-left: 300px;
		}
		input
		{
			
		}
	</style>
</head>
<body>
	<fieldset>
	<table>
		
			<h1>Registration Form</h1>
			<form action="" method="post">
				<tr><td> First Name:</td><td><input type="text" name="fname"></td></tr>
                <tr><td> Last Name:</td><td><input type="text" name="lname"></td></tr>
				<tr><td>E-mail:</td><td><input type="email" name="email"></td></tr>
				<tr><td></td><td><input type="submit" name="submit" value="ok"></td></tr>
		
			</form>
	
	</table>
	</fieldset>
    <?php 
    require('connect.php');
 if(isset($_POST['submit'])) { 
 $fname = $_POST["fname"];
 $lname = $_POST["lname"]; 
 $email = $_POST["email"]; 
$qry="insert into staff(fname,lname,email) values('$fname','$lname','$email')";
mysqli_query($link,$qry);
$res="select * from staff";
$result=mysqli_query($link,$res);
?>
<form action="" method="get"> 
<table border='1'>
<thead>
<tr>
<th>SlNo</th>
<th>First Name</th>
<th>Last Name</th>
<th>Email id</th>

<th colspan="3">Action</th>
</tr>
</thead>
<tbody>
<?php
while($row=mysqli_fetch_assoc($result))
{
    echo "<tr>
    <td>".$row['id']."</td>
    <td>".$row['fname']."</td>
    <td>".$row['lname']."</td>
    <td>".$row['email']."</td>
    <td><a href='view.php?id=".$row['id']."'>View</a></td>
    <td><a href='edit.php?id=".$row['id']."'>Edit</a></td>
    <td><a href='delete.php?id=".$row['id']."''>Delete</a></td>
    </tr>";
}
 }
 ?> 
		
</body>
</html>